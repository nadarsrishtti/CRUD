export default {
  textColor: {
    color: 'white',
  },
  linkUnderline: {
    'text-decoration': 'none',
  },
};
