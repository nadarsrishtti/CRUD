export { default as Trainee } from './Trainee';
export { default as TraineeList } from './TraineeList';
