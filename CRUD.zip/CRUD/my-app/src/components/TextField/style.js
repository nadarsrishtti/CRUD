export default {
  base: {
    padding: '12px',
    width: '100%',
    marginBottom: '5px',
  },
  error: {
    color: 'red',
  },
  errorInput: {
    border: '1px solid red',
  },
};
