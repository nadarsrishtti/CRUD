export default {
  slider: {
    padding: '12px',
    width: '100vw',
    textAlign: 'center',
  },
};
