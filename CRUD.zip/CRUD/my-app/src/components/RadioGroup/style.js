export default {
  error: {
    color: 'red',
  },
};
