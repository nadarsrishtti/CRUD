export default {
  dropDownBox: {
    width: '100%',
    padding: '15px 20px',
    background: '#ccc',
    border: '1px solid orange',
    fontSize: '15px',
    lineHeight: '20px',
  },

  options: {
    padding: '20px',
  },
  error: {
    color: 'red',
  },
};
