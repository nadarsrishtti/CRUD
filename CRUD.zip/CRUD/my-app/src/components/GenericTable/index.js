export { default as Table } from './GenericTable';
