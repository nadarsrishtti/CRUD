.env

NODE_ENV=dev
PORT=7000
MONGO_URL=mongodb://localhost:27017/users-exp-boiler
CORS_ORIGIN=http://localhost
AUTH_ACTIVE=false
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
SECRET_KEY=adasHUsfsdfkdsdfsd
NOTIFICATION_SERVICE_URL=http://localhost:8000/api

