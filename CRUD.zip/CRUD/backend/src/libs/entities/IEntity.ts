interface IEntity {
  id: string;
}

export default IEntity;
