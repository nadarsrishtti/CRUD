import NotFoundError from './notFoundError';

export default NotFoundError;
