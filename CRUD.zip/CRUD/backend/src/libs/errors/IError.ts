interface IError {
  location: string;
  msg: string;
  param: string;
  value: string;
}

export default IError;
