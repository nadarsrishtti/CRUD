import { SystemResponse } from '../../libs/response-handler';
import IUser from './IDepartment';
import { Nullable } from '../../libs/nullable';
import DepartmentService from './DepartmentService';

class DepartmentController {
    private static instance;

    public static getInstance() {
        if (!DepartmentController.instance) {
            DepartmentController.instance = new DepartmentController();
        }

        return DepartmentController.instance;
    }

    // eslint-disable-next-line class-methods-use-this
    public list = async (req, res, next): Promise<IUser[]> => {
        const { locals: { logger } } = res;
        const departmentService = new DepartmentService();
        try {
            const { limit, skip } = req.query;

            // for user service - fetch
            const result = await departmentService.list(limit, skip);
            if (!result.length) {
                logger.debug({ message: 'Data not found', option: [], data: [] });

                return next(SystemResponse.badRequestError('Data not found', ''));
            }
            logger.info({ message: 'List of Users', data: [], option: [] });
            return res.send(SystemResponse.success('List of Users ', result));
        } catch (err) {
            logger.error({ message: err.message, option: [{ Error: err.stack }] });
            return res.send(SystemResponse.internalServerError);
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public create = async (req, res) => {
        const { locals: { logger } } = res;
        const departmentService = new DepartmentService();

        try {
            const result = await departmentService.create(req.body);
            logger.info({ messgae: 'User Created Successfully', data: [], option: [] });
            return res.send(SystemResponse.success('User created', result));
        } catch (err) {
            logger.error({ message: err.message, option: [{ Error: err.stack }] });
            return res.send(SystemResponse.internalServerError('Failed', err));
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public get = async (req, res): Promise<Nullable<IUser>> => {
        const { locals: { logger } } = res;
        const departmentService = new DepartmentService();

        try {
            const { id } = req.params;
            const result = await departmentService.get({ id });
            logger.info({ messgae: 'User found', data: [] });
            return res.send(SystemResponse.success('User found', result));
        } catch (err) {
            logger.error({ message: err.message, option: [{ Error: err.stack }] });
            return res.send(SystemResponse.internalServerError);
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public update = async (req, res) => {
        const { locals: { logger } } = res;
        const departmentService = new DepartmentService();

        try {
            const data = req.body;
            const result = await departmentService.update(data.id, data);
            logger.info({ messgae: 'User updated', data: [] });
            return res.send(SystemResponse.success('User updated successfully', result));
        } catch (err) {
            logger.error({ message: err.message, option: [{ Error: err.stack }] });
            return res.send(SystemResponse.internalServerError);
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public delete = async (req, res) => {
        const { locals: { logger } } = res;
        const departmentService = new DepartmentService();

        try {
            const { id } = req.body;
            const result = await departmentService.delete({
                id,
            });
            logger.info({ messgae: 'User deleted', data: [], option: [] });
            return res.send(SystemResponse.success('User deleted', result));
        } catch (err) {
            logger.error({ message: err.message, option: [{ Error: err.stack }] });
            return res.send(SystemResponse.internalServerError);
        }
    };
}

export default DepartmentController.getInstance();
