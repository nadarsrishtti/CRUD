import IQueryEntity from './IQueryEntity';

interface IQueryBaseDelete extends IQueryEntity {
  id?: string;
}

export default IQueryBaseDelete;
