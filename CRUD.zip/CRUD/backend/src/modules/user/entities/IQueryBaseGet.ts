import IQueryEntity from './IQueryEntity';

interface IQueryBaseGet extends IQueryEntity {
  id: string;
}

export default IQueryBaseGet;
