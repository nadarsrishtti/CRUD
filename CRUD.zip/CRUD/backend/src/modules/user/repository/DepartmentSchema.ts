import mongoose from 'mongoose';
import BaseSchema from '../../../libs/BaseRepo/BaseSchema';

export default class DepartmentSchema extends BaseSchema {
    constructor(options: any) {
        const baseSchema = {
            departmentName: String,
            categoryName: String,
            location: String,
            salary: Number,
            employeeID: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
        };
        super(baseSchema, options);
    }
}
