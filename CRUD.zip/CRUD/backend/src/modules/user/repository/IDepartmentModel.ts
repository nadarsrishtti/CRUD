import mongoose from 'mongoose';
import IBaseDocument from '../../../libs/BaseRepo/IBaseDocument';

interface IDepartmentModel extends IBaseDocument {
  id: string;
  departmentName: String,
  categoryName: String,
  location: String,
  salary: Number,
  employeeID: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
}

export default IDepartmentModel;
