/* eslint-disable no-underscore-dangle */
import * as mongoose from 'mongoose';
import IDepartmentModel from './IDepartmentModel';
import DepartmentSchema from './DepartmentSchema';

export const departmentSchema = new DepartmentSchema({
    collection: 'Department-Management',
    toJSON: {
        transform: (doc, ret) => {
            const res = ret;
            res.id = res._id;
            delete res._id;
            delete res.__v;
        },
        virtuals: true,
    },
});

/**
 * @typedef User
 */

export const departmentModel: mongoose.Model<IDepartmentModel> = mongoose.model<IDepartmentModel>(
    'Department-Management',
    departmentSchema,
);
