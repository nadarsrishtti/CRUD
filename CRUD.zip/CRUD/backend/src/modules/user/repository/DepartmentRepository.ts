import * as mongoose from 'mongoose';
import { Nullable } from '../../../libs/nullable';
import BaseRepository from '../../../libs/BaseRepo/BaseRepository';
import {
    IQueryCreate, IQueryDelete, IQueryGet, IQueryList, IQueryUpdate,
} from '../entities';
import IDepartmentModel from './IDepartmentModel';
import { departmentModel } from './DepartmentModel';

class DepartmentRepository extends BaseRepository<IDepartmentModel,
  mongoose.Model<IDepartmentModel>> {
    constructor() {
        super(departmentModel);
    }

    public async list(options: IQueryList, projection?): Promise<IDepartmentModel[]> {
        return super.list({}, projection, options);
    }

    public async create(options: IQueryCreate): Promise<IDepartmentModel> {
        return super.create(options);
    }

    public async get(query: IQueryGet): Promise<Nullable<IDepartmentModel>> {
        return super.findOne(query);
    }

    public async count(query): Promise<number> {
        return super.count(query);
    }

    public async findOne(query): Promise<IDepartmentModel> {
        return super.findOne(query);
    }

    public async update(options, itemsToUpdate: IQueryUpdate): Promise<IDepartmentModel> {
        return super.update(options, itemsToUpdate);
    }

    public async delete(query: IQueryDelete): Promise<mongoose.UpdateQuery<IDepartmentModel>> {
        return super.delete(query);
    }
}
export default DepartmentRepository;
