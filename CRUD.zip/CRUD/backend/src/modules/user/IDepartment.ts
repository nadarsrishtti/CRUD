import mongoose from 'mongoose';
import IEntity from '../../libs/entities/IEntity';

interface IDepartment extends IEntity {
    departmentName: String,
    categoryName: String,
    location: String,
    salary: Number,
    employeeID: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
}

export default IDepartment;
