import * as mongoose from 'mongoose';
import IDepartment from './IDepartment';
import DepartmentRepository from './repository/DepartmentRepository';

class DepartmentService {
    private departmentRepository: DepartmentRepository;

    public constructor() {
        this.departmentRepository = new DepartmentRepository();
    }

    public async list(limit: number, skip: number, projection?): Promise<IDepartment[]> {
        return this.departmentRepository.list({ limit, skip }, projection);
    }

    public async create(query): Promise<IDepartment> {
        return this.departmentRepository.create(query);
    }

    public async get(query): Promise<IDepartment> {
        const { id } = query;
        return this.departmentRepository.get({ id });
    }

    public async update(option: string, query): Promise<IDepartment> {
        return this.departmentRepository.update(option, query);
    }

    public async delete(query): Promise<mongoose.UpdateQuery<IDepartment>> {
        const { id } = query;
        return this.departmentRepository.delete({
            id,
        });
    }
}

export default DepartmentService;
