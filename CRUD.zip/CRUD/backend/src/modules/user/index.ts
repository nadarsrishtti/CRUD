import DepartmentRoutes from './router';

export default DepartmentRoutes;
