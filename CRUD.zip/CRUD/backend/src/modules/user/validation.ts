import { isValidObjectId } from '../../libs/MongoUtils';

export default Object.freeze({
    create: {
        departmentName: {
            errorMessage: 'Department Name is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Department Name should be at least 2 chars long',
                options: { min: 2 },
            },
        },
        categoryName: {
            errorMessage: 'Category Name is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Category Name should be at least 2 chars long',
                options: { min: 2 },
            },
        },
        location: {
            errorMessage: 'Location is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Location should be at least 2 chars long',
                options: { min: 2 },
            },
        },
        salary: {
            errorMessage: 'Salary is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Salary should be at least 2 chars long',
                options: { min: 2 },
            },
        },
        employeeID: {
            custom: {
                options: (id: string) => isValidObjectId(id),
            },
            errorMessage: 'Bad ID format',
            in: ['body'],
        },
    },

    delete: {
        id: {
            custom: {
                options: (id: string) => isValidObjectId(id),
            },
            errorMessage: 'Bad ID format',
            in: ['body'],
        },
    },

    get: {
        id: {
            custom: {
                options: (id: string) => isValidObjectId(id),
            },
            errorMessage: 'Bad ID format',
            in: ['params'],
        },
    },
    list: {
        limit: {
            errorMessage: 'limit is wrong',
            in: ['query'],
            isInt: true,
            optional: true,
            toInt: true,
        },
        skip: {
            errorMessage: 'skip count is wrong',
            in: ['query'],
            isInt: true,
            optional: true,
            toInt: true,
        },
    },

    update: {
        id: {
            custom: {
                options: (id: string) => isValidObjectId(id),
            },
            errorMessage: 'Bad ID format',
            in: ['body'],
        },
        departmentName: {
            errorMessage: 'Department Name is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Department Name should be at least 2 chars long',
                options: { min: 2 },
            },
        },
        categoryName: {
            errorMessage: 'Category Name is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Category Name should be at least 2 chars long',
                options: { min: 2 },
            },
        },
        location: {
            errorMessage: 'Location is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Location should be at least 2 chars long',
                options: { min: 2 },
            },
        },
        salary: {
            errorMessage: 'Salary is wrong!',
            in: ['body'],
            isLength: {
                errorMessage: 'Salary should be at least 2 chars long',
                options: { min: 2 },
            },
        },

    },

});
