import IQueryEntity from './IQueryEntity';

interface IQueryBaseGet extends IQueryEntity {
  _id?: string;
}

export default IQueryBaseGet;
