import IQueryEntity from './IQueryEntity';

interface IQueryBaseDelete extends IQueryEntity {
  _id?: string;
}

export default IQueryBaseDelete;
