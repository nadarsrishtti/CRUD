import IQueryBaseGet from './IQueryBaseGet';

interface IQueryGet extends IQueryBaseGet {
  id: string;
}

export default IQueryGet;
