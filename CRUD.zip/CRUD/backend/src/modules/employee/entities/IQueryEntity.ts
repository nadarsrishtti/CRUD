interface IQueryEntity {}

export default IQueryEntity;
