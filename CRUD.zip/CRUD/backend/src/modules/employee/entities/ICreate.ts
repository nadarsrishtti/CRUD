import IQueryBaseCreate from './IQueryBaseCreate';

interface ICreate extends IQueryBaseCreate {
    firstName?: String,
    lastName?: String,
    gender?: String,
    hobbies?: [String],
    email?: String,
    password?: String,
 }

export default ICreate;
