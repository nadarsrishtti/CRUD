import IQueryBaseUpdate from './IQueryBaseUpdate';

interface IQueryUpdate extends IQueryBaseUpdate {
    firstName?: String,
    lastName?: String,
    gender?: String,
    hobbies?: [String],
}

export default IQueryUpdate;
