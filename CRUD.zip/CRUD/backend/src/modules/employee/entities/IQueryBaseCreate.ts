import IQueryEntity from './IQueryEntity';

interface IQueryBaseCreate extends IQueryEntity {}

export default IQueryBaseCreate;
