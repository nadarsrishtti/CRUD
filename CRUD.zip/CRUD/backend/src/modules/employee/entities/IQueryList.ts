import IQueryBaseList from "./IQueryBaseList";

interface IQueryList extends IQueryBaseList {
    limit?: number;
    skip?: number;
    firstName?: String;
    lastName?: String;
    gender?: String;
    hobbies?: [String];
    email?: String;
    password?: String;
}

export default IQueryList;
