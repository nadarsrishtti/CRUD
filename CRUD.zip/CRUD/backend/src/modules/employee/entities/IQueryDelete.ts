import IQueryBaseDelete from './IQueryBaseDelete';

interface IQueryDelete extends IQueryBaseDelete {
  id?: string;
}

export default IQueryDelete;
