import IQueryEntity from './IQueryEntity';

interface IQueryBaseUpdate extends IQueryEntity {
  id?: string;
}

export default IQueryBaseUpdate;
