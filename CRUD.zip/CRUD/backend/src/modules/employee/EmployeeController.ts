/* eslint-disable class-methods-use-this */
import * as bcrypt from 'bcrypt';
import { SystemResponse } from '../../libs/response-handler';
import IEmployee from './IEmployee';
import { Nullable } from '../../libs/nullable';
import EmployeeService from './EmployeeService';
import * as constants from '../../config/constants';

class EmployeeController {
    private static instance;

    public static getInstance() {
        if (!EmployeeController.instance) {
            EmployeeController.instance = new EmployeeController();
        }

        return EmployeeController.instance;
    }

    // eslint-disable-next-line class-methods-use-this
    public list = async (req, res): Promise<IEmployee[]> => {
        const {
            locals: { logger },
        } = res;
        const employeeService = new EmployeeService();
        try {
            const { limit, skip } = req.query;
            const result = await employeeService.list(limit, skip);
            if (!result.length) {
                logger.debug({
                    message: 'Data not found',
                    option: [],
                    data: [],
                });
                return res.send(
                    SystemResponse.badRequestError('Data not found', ''),
                );
            }
            logger.info({ message: 'List of ToDo', data: [], option: [] });
            return res.send(SystemResponse.success('List of ToDo ', result));
        } catch (err) {
            logger.error({
                message: err.message,
                option: [{ Error: err.stack }],
            });
            return res.send(SystemResponse.internalServerError);
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public create = async (req, res) => {
        const {
            locals: { logger },
        } = res;
        const employeeService = new EmployeeService();
        try {
            const {
                email, password, firstName, lastName, gender, hobbies, designation
            } = req.body;
            const hashPassword = await bcrypt.hash(password, constants.BCRYPT_SALT_ROUNDS);
            const result = await employeeService.create({
                email,
                password: hashPassword,
                firstName,
                lastName,
                gender,
                hobbies,
                designation,
            });
            logger.info({
                messgae: 'Record Added Successfully',
                data: [],
                option: [],
            });
            return res.send(
                SystemResponse.success('Record Added Succefully', result),
            );
        } catch (err) {
            logger.error({
                message: err.message,
                option: [{ Error: err.stack }],
            });
            return res.send(SystemResponse.internalServerError);
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public get = async (req, res): Promise<Nullable<IEmployee>> => {
        const {
            locals: { logger },
        } = res;
        const employeeService = new EmployeeService();
        try {
            const { id } = req.params;
            const result = await employeeService.get({
                id,
            });
            logger.info({ messgae: 'ToDo record found', data: [] });
            return res.send(
                SystemResponse.success('ToDo record Found..!', result),
            );
        } catch (err) {
            logger.error({
                message: err.message,
                option: [{ Error: err.stack }],
            });
            return res.send(SystemResponse.internalServerError);
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public update = async (req, res) => {
        const {
            locals: { logger },
        } = res;
        const employeeService = new EmployeeService();
        try {
            const data = req.body;
            const result = await employeeService.update(data.id, data);
            logger.info({ messgae: 'Record updated', data: [] });
            return res.send(
                SystemResponse.success('Record updated successfully', result),
            );
        } catch (err) {
            logger.error({
                message: err.message,
                option: [{ Error: err.stack }],
            });
            return res.send(SystemResponse.internalServerError);
        }
    };

    // eslint-disable-next-line class-methods-use-this
    public delete = async (req, res) => {
        const {
            locals: { logger },
        } = res;
        const employeeService = new EmployeeService();
        try {
            const { id } = req.param;
            const result = await employeeService.delete({
                id,
            });
            logger.info({ messgae: 'Record deleted', data: [], option: [] });
            return res.send(SystemResponse.success('Record deleted', result));
        } catch (err) {
            logger.error({
                message: err.message,
                option: [{ Error: err.stack }],
            });
            return res.send(SystemResponse.internalServerError);
        }
    };

    public registration = async (req, res, next) => {
        const { locals: { logger } } = res;
        const employeeService = new EmployeeService();

        try {
            const { email, password, firstName } = req.body;
            const hashPassword = await bcrypt.hash(password, constants.BCRYPT_SALT_ROUNDS);
            const result = await employeeService.create({
                email,
                password: hashPassword,
                firstName,
            });
            logger.info({
                message: 'Employee registered',
                data: [],
                option: [],
            });
            return res.send(
                SystemResponse.success(
                    'Employee registered successfully!',
                    result,
                ),
            );
        } catch (err) {
            logger.error({
                message: err.message,
                option: [{ Error: err.stack }],
            });
            return next(err);
        }
    };
}

export default EmployeeController.getInstance();
