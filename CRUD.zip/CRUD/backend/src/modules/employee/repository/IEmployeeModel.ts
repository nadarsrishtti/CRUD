import IBaseDocument from '../../../libs/BaseRepo/IBaseDocument';

interface IEmployeeModel extends IBaseDocument {
  id: string;
  firstName: String,
  lastName: String,
  gender: String,
  hobbies: [String],
  email: String,
  password: String,
}

export default IEmployeeModel;
