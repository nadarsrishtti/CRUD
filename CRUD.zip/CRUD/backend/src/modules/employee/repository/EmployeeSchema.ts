import BaseSchema from '../../../libs/BaseRepo/BaseSchema';

export default class EmployeeSchema extends BaseSchema {
    constructor(options: any) {
        const baseSchema = {
            firstName: {
                type: String,
            },
            lastName: {
                type: String,
            },
            gender: {
                type: String,
            },
            hobbies: {
                type: String,
            },
            email: {
                type: String,
            },
            password: {
                type: String,
            },
            designation: {
                type: String,
            },
        };
        super(baseSchema, options);
    }
}
