/* eslint-disable no-underscore-dangle */
import * as mongoose from 'mongoose';

import IEmployeeModel from './IEmployeeModel';
import EmployeeSchema from './EmployeeSchema';

export const employeeSchema = new EmployeeSchema({
    collection: 'Employee-Management',
    toJSON: {
        transform: (doc, ret) => {
            const res = ret;
            res.id = res._id;
            delete res._id;
            delete res.__v;
        },
        virtuals: true,
    },
});

export const employeeModel: mongoose.Model<IEmployeeModel> = mongoose.model<IEmployeeModel>(
    'Employee-Management',
    employeeSchema,
);
