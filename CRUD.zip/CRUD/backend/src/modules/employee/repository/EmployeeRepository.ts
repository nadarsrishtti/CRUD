import * as mongoose from 'mongoose';
import { Nullable } from '../../../libs/nullable';
import BaseRepository from '../../../libs/BaseRepo/BaseRepository';
import {
    IQueryCreate, IQueryDelete, IQueryGet, IQueryList, IQueryUpdate,
} from '../entities';
import IEmployeeModel from './IEmployeeModel';
import { employeeModel } from './EmployeeModel';

class EmployeeRepository extends BaseRepository<IEmployeeModel,
  mongoose.Model<IEmployeeModel>> {
    constructor() {
        super(employeeModel);
    }

    public async list(options: IQueryList, projection?): Promise<IEmployeeModel[]> {
        return super.list({}, projection, options);
    }

    public async create(options: IQueryCreate): Promise<IEmployeeModel> {
        return super.create(options);
    }

    public async get(query: IQueryGet): Promise<Nullable<IEmployeeModel>> {
        return super.findOne(query);
    }

    public async count(query): Promise<number> {
        return super.count(query);
    }

    public async findOne(query): Promise<IEmployeeModel> {
        return super.findOne(query);
    }

    public async update(options, itemsToUpdate: IQueryUpdate): Promise<IEmployeeModel> {
        return super.update(options, itemsToUpdate);
    }

    public async delete(query: IQueryDelete): Promise<mongoose.UpdateQuery<IEmployeeModel>> {
        return super.delete({ id: query.id });
    }
}
export default EmployeeRepository;
