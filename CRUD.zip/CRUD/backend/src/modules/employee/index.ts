import EmployeeRoutesController from './router';

export default EmployeeRoutesController;
