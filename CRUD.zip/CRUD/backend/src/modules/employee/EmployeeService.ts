import * as mongoose from 'mongoose';
import IEmployee from './IEmployee';
import EmployeeRepository from './repository/EmployeeRepository';

class ToDoService {
    private employeeRepository: EmployeeRepository;

    public constructor() {
        this.employeeRepository = new EmployeeRepository();
    }

    public async list(limit: number, skip: number, projection?): Promise<IEmployee[]> {
        return this.employeeRepository.list({ limit, skip }, projection);
    }

    public async create(query): Promise<IEmployee> {
        return this.employeeRepository.create(query);
    }

    public async get(query): Promise<IEmployee> {
        const { id } = query;
        return this.employeeRepository.get({ id });
    }

    public async update(option: string, query): Promise<IEmployee> {
        return this.employeeRepository.update(option, query);
    }

    public async delete(query): Promise<mongoose.UpdateQuery<IEmployee>> {
        const { id } = query;
        return this.employeeRepository.delete({
            id,
        });
    }
}

export default ToDoService;
