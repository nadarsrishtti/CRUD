import IEntity from '../../libs/entities/IEntity';

interface IEmployee extends IEntity {
    firstName: String,
    lastName: String,
    gender: String,
    hobbies: [String],
    email: String,
    password: String,
}

export default IEmployee;
