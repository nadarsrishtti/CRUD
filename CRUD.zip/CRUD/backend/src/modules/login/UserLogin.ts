import * as jwt from 'jsonwebtoken';
import * as bcrypt from 'bcrypt';
import { SystemResponse } from '../../libs/response-handler';
import config from '../../config/configuration';
import EmployeeRepository from '../employee/repository/EmployeeRepository';

class UserLogin {
    public static hashMatch = async (data : any, logger) => {
        console.log('isnide--hashMatch----->');
        const { email } = data;
        const employeeRepository: EmployeeRepository = new EmployeeRepository();
        const validateEmail = await employeeRepository.findOne({ email });
        console.log(' email:', email);
        console.log('validateEmail-->', validateEmail);
        const match = await bcrypt.compare(data.password, validateEmail.password);
        if (match) {
            return validateEmail;
        }
        logger.debug('Invalid Credential');
        throw new Error('Invalid Credential');
    };

    public static login = async (req, res) => {
        console.log('isnide------->', req.body);
        const { logger } = res.locals;
        try {
            const validateEmail = await UserLogin.hashMatch(req.body, logger);
            const token = jwt.sign({ data: validateEmail.email }, config.secret, { expiresIn: '1hr' });
            logger.info({ message: 'Token generated Successfully' });
            return res.send(SystemResponse.success('Success', {
                message: 'Token generated Successfully',
                data: {
                    token,
                },
                status: 'success',
            }));
        } catch (e) {
            return res.send(SystemResponse.badRequestError('Invalid Credential', e));
        }
    };

    public static mailMatch = async (data : any, logger) => {
        const employeeRepository: EmployeeRepository = new EmployeeRepository();
        const validateEmail = await employeeRepository.findOne({ email: data.email });
        if (validateEmail) {
            return validateEmail;
        }
        logger.debug('Invalid Email');
        throw new Error('Invalid Email');
    };
}
export default UserLogin;
