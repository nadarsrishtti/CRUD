/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */
// eslint-disable-next-line import/prefer-default-export
export enum Services {
    NOTIFICATION_SERVICE = 'NotificationService',
}
